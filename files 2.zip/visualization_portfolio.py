"""
==========================================================
  Task 3: Data Visualization Portfolio
  Charts: Bar, Line, Heatmap, Area, Dashboard
  Dataset: World Bank GDP (2000–2023), 30 major economies
==========================================================
"""

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec
import seaborn as sns
import numpy as np
import warnings
warnings.filterwarnings('ignore')

# ── Load dataset (from Task 1 scraping)
df = pd.read_csv("web_scraping_project/major_economies_gdp.csv")

# ── Theme
BG     = "#0F172A"   # deep navy background
CARD   = "#1E293B"   # panel background
TEXT   = "#F1F5F9"   # primary text
MUTED  = "#94A3B8"   # secondary text
ACCENT = "#38BDF8"   # highlight blue

PALETTE = ["#38BDF8","#F97316","#A78BFA","#34D399","#FB7185",
           "#FBBF24","#60A5FA","#F472B6","#4ADE80","#FCA5A5"]

plt.rcParams.update({
    "figure.facecolor":  BG,
    "axes.facecolor":    CARD,
    "text.color":        TEXT,
    "axes.labelcolor":   TEXT,
    "xtick.color":       MUTED,
    "ytick.color":       MUTED,
    "axes.edgecolor":    "#334155",
    "grid.color":        "#1E293B",
    "font.family":       "DejaVu Sans",
    "font.size":         10,
})

TOP10 = ["United States","China","Germany","Japan","India",
         "United Kingdom","France","Italy","Brazil","Canada"]

# ══════════════════════════════════════════════════════
# CHART 1 — Horizontal Bar: Top 10 Economies (2023)
# Best for: ranking comparisons at a point in time
# ══════════════════════════════════════════════════════
def chart_bar_ranking():
    latest = df[df["Year"] == 2023]
    top10  = latest[latest["Country Name"].isin(TOP10)].nlargest(10, "Value_Billions")

    fig, ax = plt.subplots(figsize=(12, 7), facecolor=BG)
    ax.set_facecolor(CARD)

    bars = ax.barh(top10["Country Name"][::-1], top10["Value_Billions"][::-1],
                   color=PALETTE, edgecolor="none", height=0.65)

    for bar, val in zip(bars, top10["Value_Billions"][::-1]):
        ax.text(bar.get_width() + 180, bar.get_y() + bar.get_height() / 2,
                f"${val:,.0f}B", va="center", color=TEXT, fontsize=10, fontweight="bold")

    ax.set_title("Top 10 Economies by GDP — 2023",
                 color=TEXT, fontsize=16, fontweight="bold", pad=20)
    ax.set_xlabel("GDP (USD Billions)", color=MUTED, fontsize=10)
    ax.spines[:].set_visible(False)
    ax.grid(axis="x", color="#334155", linewidth=0.5, alpha=0.6)
    ax.set_xlim(0, 34000)
    ax.tick_params(left=False)
    fig.text(0.98, 0.02, "Source: World Bank", ha="right", color=MUTED, fontsize=8)

    plt.tight_layout()
    plt.savefig("viz_01_top10_gdp_bar.png", dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print("✅ Chart 1 — Bar ranking saved")


# ══════════════════════════════════════════════════════
# CHART 2 — Multi-Line: GDP Trajectories Over Time
# Best for: trends, growth, divergence over time
# ══════════════════════════════════════════════════════
def chart_line_trends():
    track   = ["United States","China","India","Germany","Japan","United Kingdom","France"]
    colors7 = ["#38BDF8","#F97316","#A78BFA","#34D399","#FB7185","#FBBF24","#60A5FA"]

    fig, ax = plt.subplots(figsize=(14, 7), facecolor=BG)
    ax.set_facecolor(CARD)

    for country, color in zip(track, colors7):
        d = df[df["Country Name"] == country].sort_values("Year")
        ax.plot(d["Year"], d["Value_Billions"], color=color, linewidth=2.5)
        last = d.iloc[-1]
        ax.annotate(country.replace("United ", "U."),
                    xy=(last["Year"], last["Value_Billions"]),
                    xytext=(6, 0), textcoords="offset points",
                    color=color, fontsize=8.5, va="center")

    ax.set_title("GDP Trajectory of Major Economies (2000–2023)",
                 color=TEXT, fontsize=16, fontweight="bold", pad=20)
    ax.set_xlabel("Year", color=MUTED, fontsize=10)
    ax.set_ylabel("GDP (USD Billions)", color=MUTED, fontsize=10)
    ax.spines[:].set_visible(False)
    ax.grid(color="#334155", linewidth=0.5, alpha=0.6)
    ax.set_xlim(2000, 2026)
    fig.text(0.98, 0.02, "Source: World Bank", ha="right", color=MUTED, fontsize=8)

    plt.tight_layout()
    plt.savefig("viz_02_gdp_trend_line.png", dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print("✅ Chart 2 — Line trends saved")


# ══════════════════════════════════════════════════════
# CHART 3 — Heatmap: Year-on-Year Growth Rates
# Best for: comparing performance across two dimensions
# ══════════════════════════════════════════════════════
def chart_heatmap_growth():
    countries = ["United States","China","India","Germany","Japan",
                 "United Kingdom","France","Brazil","Australia","Canada"]
    pivot     = df[df["Country Name"].isin(countries)].pivot(
                    index="Country Name", columns="Year", values="Value_Billions")
    pct       = pivot.pct_change(axis=1) * 100
    pct_sel   = pct[[y for y in range(2005, 2024, 2)]]

    fig, ax = plt.subplots(figsize=(14, 6), facecolor=BG)
    ax.set_facecolor(CARD)

    cmap = sns.diverging_palette(10, 220, as_cmap=True)
    sns.heatmap(pct_sel, ax=ax, cmap=cmap, center=0, annot=True, fmt=".1f",
                linewidths=0.5, linecolor="#0F172A", annot_kws={"size": 8},
                cbar_kws={"shrink": 0.8, "label": "YoY Growth %"})

    ax.set_title("GDP Year-on-Year Growth Rate (%) — Every 2 Years",
                 color=TEXT, fontsize=15, fontweight="bold", pad=16)
    ax.set_xlabel("Year", color=MUTED)
    ax.set_ylabel("", color=MUTED)
    plt.setp(ax.get_xticklabels(), color=TEXT, fontsize=9)
    plt.setp(ax.get_yticklabels(), color=TEXT, fontsize=9, rotation=0)
    ax.collections[0].colorbar.ax.yaxis.label.set_color(TEXT)
    ax.collections[0].colorbar.ax.tick_params(colors=MUTED)
    fig.text(0.98, 0.01, "Source: World Bank", ha="right", color=MUTED, fontsize=8)

    plt.tight_layout()
    plt.savefig("viz_03_growth_heatmap.png", dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print("✅ Chart 3 — Heatmap saved")


# ══════════════════════════════════════════════════════
# CHART 4 — Stacked Area: Share of Global GDP
# Best for: part-to-whole relationships over time
# ══════════════════════════════════════════════════════
def chart_area_global_share():
    world_total = df.groupby("Year")["Value_Billions"].sum()
    track5      = ["United States","China","India","Germany","Japan"]
    area_colors = ["#38BDF8","#F97316","#A78BFA","#34D399","#FB7185","#475569"]

    share_data = {}
    for c in track5:
        d = df[df["Country Name"] == c].set_index("Year")["Value_Billions"]
        share_data[c] = (d / world_total * 100).fillna(0)

    years = sorted(df["Year"].unique())
    share_df         = pd.DataFrame(share_data, index=years)
    share_df["Others"] = 100 - share_df.sum(axis=1)

    fig, ax = plt.subplots(figsize=(14, 7), facecolor=BG)
    ax.set_facecolor(CARD)
    ax.stackplot(share_df.index,
                 [share_df[c] for c in share_df.columns],
                 labels=share_df.columns,
                 colors=area_colors, alpha=0.85)

    ax.set_title("Share of Global GDP (%) — 2000 to 2023",
                 color=TEXT, fontsize=16, fontweight="bold", pad=20)
    ax.set_xlabel("Year", color=MUTED, fontsize=10)
    ax.set_ylabel("Share of World GDP (%)", color=MUTED, fontsize=10)
    ax.spines[:].set_visible(False)
    ax.grid(axis="y", color="#334155", linewidth=0.5, alpha=0.4)
    ax.set_xlim(2000, 2023); ax.set_ylim(0, 100)
    ax.legend(loc="lower left", framealpha=0.2, labelcolor=TEXT, fontsize=9, ncol=2)
    fig.text(0.98, 0.02, "Source: World Bank", ha="right", color=MUTED, fontsize=8)

    plt.tight_layout()
    plt.savefig("viz_04_global_share_area.png", dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print("✅ Chart 4 — Stacked area saved")


# ══════════════════════════════════════════════════════
# DASHBOARD — 4-panel executive summary
# ══════════════════════════════════════════════════════
def chart_dashboard():
    fig = plt.figure(figsize=(18, 12), facecolor=BG)
    fig.suptitle("Global Economy Dashboard  |  2000–2023",
                 color=TEXT, fontsize=20, fontweight="bold", y=0.98)
    fig.text(0.5, 0.955, "Source: World Bank Public Dataset (CC0 License)",
             ha="center", color=MUTED, fontsize=10)
    gs = GridSpec(2, 3, figure=fig, hspace=0.42, wspace=0.35,
                  left=0.06, right=0.97, top=0.92, bottom=0.07)

    # Panel A — Bar
    ax1 = fig.add_subplot(gs[0, :2])
    ax1.set_facecolor(CARD)
    latest = df[df["Year"] == 2023]
    top10  = latest[latest["Country Name"].isin(TOP10)].nlargest(10, "Value_Billions")
    bars   = ax1.barh(range(10), top10["Value_Billions"].values, color=PALETTE, height=0.65, edgecolor="none")
    ax1.set_yticks(range(10)); ax1.set_yticklabels(top10["Country Name"].values, fontsize=9)
    for i, (bar, val) in enumerate(zip(bars, top10["Value_Billions"].values)):
        ax1.text(val + 200, i, f"${val:,.0f}B", va="center", color=TEXT, fontsize=8.5, fontweight="bold")
    ax1.set_title("Top 10 Economies — GDP 2023", color=TEXT, fontsize=12, fontweight="bold", pad=10)
    ax1.set_xlabel("USD Billions", color=MUTED, fontsize=9)
    ax1.spines[:].set_visible(False)
    ax1.grid(axis="x", color="#334155", linewidth=0.5, alpha=0.5)
    ax1.set_xlim(0, 33000); ax1.tick_params(left=False)

    # Panel B — KPI Cards
    ax2 = fig.add_subplot(gs[0, 2]); ax2.set_facecolor(BG); ax2.axis("off")
    w23  = df[df["Year"]==2023]["Value_Billions"].sum()
    w00  = df[df["Year"]==2000]["Value_Billions"].sum()
    ind  = df[df["Country Name"]=="India"]
    ig   = ((ind[ind["Year"]==2023]["Value_Billions"].values[0] /
             ind[ind["Year"]==2000]["Value_Billions"].values[0]) - 1) * 100
    kpis = [("🌍 World GDP 2023", f"${w23/1000:.1f}T"),
            ("📈 Growth since 2000", f"+{((w23/w00)-1)*100:.0f}%"),
            ("🏆 #1 Economy", "USA  $27.4T"),
            ("🇨🇳 China (2023)", "$17.8T"),
            ("🇮🇳 India growth", f"+{ig:.0f}% since 2000"),
            ("📊 Countries tracked", "30 nations")]
    for i, (label, val) in enumerate(kpis):
        y = 0.92 - i * 0.16
        rect = mpatches.FancyBboxPatch((0.02, y-0.07), 0.96, 0.13,
            boxstyle="round,pad=0.01", facecolor=CARD, edgecolor="#334155",
            linewidth=1, transform=ax2.transAxes)
        ax2.add_patch(rect)
        ax2.text(0.08, y+0.025, label, transform=ax2.transAxes, color=MUTED, fontsize=8)
        ax2.text(0.08, y-0.035, val,   transform=ax2.transAxes, color=ACCENT, fontsize=11, fontweight="bold")

    # Panel C — Line
    ax3 = fig.add_subplot(gs[1, :2]); ax3.set_facecolor(CARD)
    track   = ["United States","China","India","Germany","Japan","United Kingdom"]
    lcolors = ["#38BDF8","#F97316","#A78BFA","#34D399","#FB7185","#FBBF24"]
    for c, col in zip(track, lcolors):
        d = df[df["Country Name"]==c].sort_values("Year")
        ax3.plot(d["Year"], d["Value_Billions"], color=col, linewidth=2.2, label=c)
        last = d.iloc[-1]
        ax3.annotate(c.split()[0], xy=(last["Year"], last["Value_Billions"]),
                     xytext=(4, 0), textcoords="offset points", color=col, fontsize=8, va="center")
    ax3.set_title("GDP Trajectory 2000–2023", color=TEXT, fontsize=12, fontweight="bold", pad=10)
    ax3.set_xlabel("Year", color=MUTED, fontsize=9); ax3.set_ylabel("USD Billions", color=MUTED, fontsize=9)
    ax3.spines[:].set_visible(False)
    ax3.grid(color="#334155", linewidth=0.5, alpha=0.4)
    ax3.set_xlim(2000, 2026); ax3.legend(fontsize=8, framealpha=0.15, labelcolor=TEXT, loc="upper left")

    # Panel D — Pie
    ax4 = fig.add_subplot(gs[1, 2]); ax4.set_facecolor(CARD)
    pie_c = ["United States","China","Germany","Japan","India"]
    pie_v = [latest[latest["Country Name"]==c]["Value_Billions"].values[0] for c in pie_c]
    total = df[df["Year"]==2023]["Value_Billions"].sum()
    pie_v.append(total - sum(pie_v)); pie_c.append("Others")
    pie_colors = ["#38BDF8","#F97316","#A78BFA","#34D399","#FB7185","#475569"]
    wedges, texts, autotexts = ax4.pie(
        pie_v, labels=None, colors=pie_colors, autopct="%1.1f%%",
        startangle=140, pctdistance=0.75,
        wedgeprops={"edgecolor": BG, "linewidth": 2},
        textprops={"color": TEXT, "fontsize": 8})
    for at in autotexts: at.set_fontsize(7.5); at.set_color(BG); at.set_fontweight("bold")
    ax4.legend(pie_c, loc="lower center", bbox_to_anchor=(0.5, -0.18),
               ncol=2, fontsize=8, framealpha=0.1, labelcolor=TEXT)
    ax4.set_title("Global GDP Share 2023", color=TEXT, fontsize=12, fontweight="bold", pad=10)

    plt.savefig("viz_dashboard.png", dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print("✅ Dashboard saved")


# ── Run all
if __name__ == "__main__":
    print("=" * 50)
    print("  Task 3: Data Visualization Portfolio")
    print("=" * 50)
    chart_bar_ranking()
    chart_line_trends()
    chart_heatmap_growth()
    chart_area_global_share()
    chart_dashboard()
    print("\n🎉 All 5 visualizations complete!")
    print("Files: viz_01 to viz_04 + viz_dashboard.png")
